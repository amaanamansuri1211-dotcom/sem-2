#include <stdio.h>
#include<conio.h>


void main(int argc, char *argv[])
{
    int i,sum,n1,n2;

    printf("Number of arguments = %d\n", argc);

    for(i = 0; i < argc; i++)
    {
	printf("Argument %d = %s\n", i, argv[i]);
    }
    n1=atoi(argv[1]);
    n2=atoi(argv[2]);
    sum=n1+n2;
    printf("sum is %d",sum);

	getch();
}