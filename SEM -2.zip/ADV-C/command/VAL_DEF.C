#include<stdio.h>
#include<conio.h>

#define val 7
void main()
{

clrscr();
#undef val

#ifdef val
printf("Value is define");
#else
printf("value is undefine");
#endif




getch();
}