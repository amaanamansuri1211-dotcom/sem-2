#include<stdio.h>
#include<conio.h>

void main()
{
	clrscr();
	printhello();
	getch();
	add();
	getch;



}