#include<stdio.h>
#include<conio.h>
struct  point
{
	int x,y;
};
void
void main()
{
	struct point p1,p2,mid;
	clrscr();
	printf("\nEnter the value of P1");scanf("%d %d",&p1.x,&p1.y);
	printf("\nEnter the value of P2");scanf("%d %d",&p2.x,&p2.y);
