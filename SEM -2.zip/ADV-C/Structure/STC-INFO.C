#include<stdio.h>
#include<conio.h>
struct student
{
	int rno;
	char div;
	char name[50];
	int sem;
	int sub1,sub2,sub3,total;
	int per;

};
void main()
{
	struct student s1,s2;
	clrscr();
	printf("Enter Rno");scanf("%d",&s1.rno);
	printf("Enter Div");flushall();scanf("%c",&s1.div);
	printf("Enter NAME");scanf("%s",s1.name);
	printf("Enter Your Semester");scanf("%d",&s1.sem);
	printf("Enter sub1");scanf("%d",&s1.sub1);
	printf("Enter sub2");scanf("%d",&s1.sub2);
	printf("Enter sub3");scanf("%d",&s1.sub3);

	clrscr();
	printf("\n RollNo %d",&s1.rno);
	printf("\n Division %d",&s1.div);
	printf("\n your Name %d",&s1.name);
	printf("\n Semester %d",&s1.sem);
	printf("\n Adv.C %d",&s1.sub1);
	printf("\n BM %d",&s1.sub2);
	printf("\n CS %d",&s1.sub3);
	s1.total=s1.sub1+s1.sub2+s1.sub3;
	printf("Total Marks %d",s1.total);
	s1.per=s1.total/3;
	printf("Persentage=%d",s1.per);
	getch();
}