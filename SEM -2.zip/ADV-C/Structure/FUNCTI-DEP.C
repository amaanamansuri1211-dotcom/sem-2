#include<stdio.h>
#include<conio.h>
struct emp
{
  char id[30];
  char nm[40];
  char dptno[40];
};
int n=3;
void savedata();
void printdata();
void searchdata();
void main()
{
	int ch;
	char c='y';
	clrscr();
	while(c=='y')
	{
		printf("\n Press 1 to insert data:");
		printf("\n Press 2 to list all employee:");
		printf("\n Press 3 to search :");
		scanf("%d",&ch);
		switch(ch)
		{
		 case 1: savedata(); break;
		 case 2: printdata(); break;
		 case 3: searchdata(); break;
		 default: printf("\n Wrong choice");  break;
		}
		printf("\n Press y to continue:"); flushall(); scanf("%c",&c);

	}

	getch();
}
///////////////////////////////////////////////////////////////
void savedata()
{
      FILE *fp;
      int i;
	struct emp e;
	fp=fopen("emp.txt","w");
	if(fp)
	{
	      printf("\n Enter no of employee:"); scanf("%d",&n);
	      for(i=1;i<=n;i++)
	      {
	      printf("\n Enter Emp id:"); scanf("%s",e.id);
	       printf(" Enter Emp name:");  scanf("%s",e.nm);
	       printf(" Enter Emp deptmo:"); scanf("%s",e.dptno);


	       fprintf(fp,"%s %s %s\n",e.id,e.nm,e.dptno);
	}
	}
	else
	{
	printf("\n File could not open");
	}
	fclose(fp);
}
void printdata()
{
      FILE *fp;
      int i;
      int n=3;
	struct emp e;
	fp=fopen("emp.txt","r");
	if(fp)
	{

	      for(i=1;i<=n;i++)
	      {

	       fscanf(fp,"%s %s %s\n",e.id,e.nm,e.dptno);
	       printf("%s\t%s\t%s\n",e.id,e.nm,e.dptno);
		}
	}
	else
	{
	printf("\n File could not open");
	}
	fclose(fp);
}
void searchdata()
{
  FILE *fp;
	int i,n,flag=0;
	char temp[3];
	struct emp e;
	clrscr();
	fp=fopen("emp.txt","r");
	if(fp)
	{
		printf("\n Enter emp id:");
	       scanf("%s",temp);
	       for(i=1;i<=3;i++)
	       {
			fscanf(fp,"%s %s %s",e.id,e.nm,e.dptno);
			n=strcmp(temp,e.id);
			if(n==0)
			{
			flag=1;
			printf("\n Record found");
			printf("\n %s %s %s",e.id,e.nm,e.dptno);
			 }
		 } //for
			if(flag==0)
			{
			 printf("\n Record not found");
			 }

	}
	fclose(fp);
}