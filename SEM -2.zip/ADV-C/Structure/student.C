#include<stdio.h>
#include<conio.h>
#include<string.h>
struct date {
  int y,m,d;
};
struct department{
	int deptid;
	char deptnm[50];
	char hodnm[50];
	};
struct student{
 int stdid;
 char stdnm[50];
 int styr;
 int deptid;
 struct date dob;
 };
struct faculty{
 int falid;
 char falnm[50];
 int falsal;
 int deptid;
 };
 struct course{
 int corid;
 char cornm[50];
 int credit;
 int deptid;
 };///////////////////////////////////////////////////////////////
void getdept();
void getcourse();
////////////////////////////////////
struct course c[100];
struct department d[3];
//////////////////////////////////////////////////////////////////
void main()
{

	clrscr();
	getdept();
	getcourse();

	getch();
}
////////////////////////////////////////////////////////////////////
void getdept()
{
  int i;
  for(i=0;i<3;i++)
  {
   printf("\n Enter Department id ");scanf("%d",&d[i].deptid);
   printf(" Enter Department Name");scanf("%s",d[i].deptnm);
   printf(" Enter Department HOD Name");scanf("%s",d[i].hodnm);
  }
}
void getcourse()
{
   int i,j;
  for(i=0;i<10;i++)
  {
   printf("\n Enter Course id ");scanf("%d",&c[i].corid);
   printf(" Enter Course Name");scanf("%s",c[i].cornm);
   printf(" Enter Corse Credit");scanf("%d",&c[i].credit);
   for(j=0;j<3;j++)
   {
   printf("\n %d\t %s",d[j].deptid,d[j].deptnm);

   printf("Select department-id from the above data ");scanf("%d",&c[i].deptid);

  }
  }

}