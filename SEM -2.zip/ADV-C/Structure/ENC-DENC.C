#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
int key=4;
char msg[10];
int i,len;
clrscr();
printf("\n Enter the msg");scanf("%s",msg);
len=strlen(msg);
printf("\n %s is orignal message",msg);
printf("\n encriypted Message");
for(i=0;i<len;i++)
{
msg[i]=msg[i]+key;
printf("\n%c",msg[i]);
}
printf("\n Dencrypted msg");
for(i=0;i<len;i++)
{
msg[i]=msg[i]-key;
printf("\n%c",msg[i]);
}
getch();
}
