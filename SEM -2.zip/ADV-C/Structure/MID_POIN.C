#include<stdio.h>
#include<conio.h>
struct  point
{
int x,y;





};
void main()
{
  clrscr();

 getch();
}