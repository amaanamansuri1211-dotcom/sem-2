#include<stdio.h>
#include<conio.h>

	struct date
	{
	 int d,m,y;
	};
	struct cofile
	{
	int empid;
	int dep,join;
	int sal;
	};
	struct emp
	{
	 char id;
	 char nm[90];
	 int dob,add;
	 char cont[50],pin;
	 struct cofile file;
	 struct  date da;
	};


/////////////////////////////////////////////
	void swap(int,int);
	void getdata();
	void printdata();
	void getdata();
	void sortbybod();
	void sortbysal();
	void sortbyjoin();
/////////////////////////////////////////////

void main()
{
	struct emp s[10];
	struct emp temp;
	int n;

	clrscr();
	char c='y';
	int ch;


	clrscr();
	while(c=='y')
	{
	 printf("Welcome to Lj university examination Department");
	 printf("\n 1 input data: \n 2 print Data \n 3 sort Data by dob \n 4 sort Data by salary \n 5 Sort Data by date of joint");
	 scanf("%d",&ch);
	 switch(ch)
	 {
	  case 1: getData();break;
	  case 2: printData();break;
	  case 3: sortbydob();break;
	  case 4: sortbysalary();break;
	  case 5: sortby date of joint();break;
	  default : printf("Wrong choice"); break;


	 }
	 printf("\n Press 'y' to Continue");flushall();scanf("%c",&c);
	}






	getch();
}
swap(int i,int j)
{
				temp.id=s[i].id;
				s[i].id=s[j].id;
				s[j].id=temp.s[i].id;

				strcpy(temp.nm,s[i].nm);
				strcpy(s[i].nm,s[j].nm);
				strcpy(s[j].nm,temp.nm);

				strcpy(temp.add,s[i].add);
				strcpy(s[i].add,s[j].add);
				strcpy(s[j].add,temp.add);


				temp.file.dep=s[i].file.dep;
				s[i].file.dep=s[j].file.dep;
				s[j].file.dep=temp.file.dep;


				temp.file.join=s[i].file.join;
				s[i].file.join=s[j].file.join;
				s[j].file.join=temp.file.join;



				temp.file.sal=s[i].file.sal;
				s[i].file.sal=s[j].file.sal;
				s[j].file.sal=temp.file.sal;


				temp.da.y=s[i].da.y;
				s[i].da.y=s[j].da.y;
				s[j].da.y=temp.da.y;

				temp.da.m=s[i].da.m;
				s[i].da.m=s[j].da.m;
				s[j].da.m=temp.da.m;

				temp.da.d=s[i].da.d;
				s[i].da.d=s[j].da.d;
				s[j].da.d=temp.da.d;


				strcpy(temp.cont,s[i].cont);
				strcpy(s[i].cont,s[j].cont);
				strcpy(s[j].cont,temp.cont);

				strcpy(temp.pin,s[i].pin);
				strcpy(s[i].pin,s[j].pin);
				strcpy(s[j].pin,temp.pin);





}
void getdata()
{

int i;
  printf("\n Number of student");scanf("%d",&n);

     for(i=0;i<n;i++)
	{
		printf("\nEnter Employee-id : "); scanf("%c",&s[i].id);
		printf("Enter Name : "); scanf("%s",s[i].nm);
		printf("Enter the Address : ");flushall(); scanf("%d",&s[i].add);
		printf("Enter the Contact  : "); scanf("%c",&s[i].cont);
		printf("Enter the pincode : "); scanf("%c",&s[i].pin);
		printf("Enter your salary"); scanf("%d",&s[i].file.sal);
		printf("Enter your date of join") scanf("%d",&s[i].file.join);
		printf("Enter your Department");scanf("%d",&s[i].file.dep);
		printf("\n enter the DOB yyyy/mm/dd:");
		scanf("%d %d %d",&s[i].da.y,&s[i].da.m,&s[i].da.d);
	}


}
void printdata()
{
	int i;
	for(i=0;i<;i++
	{

	printf("\n Emp-Id\t Name\t Dep\t da-jo\t pin\t Add\t cont\t sal\t  Dob");
	printf("\n %d\t %s\t %d\t %d\t %c\t %c\t %c\t %d\t  (%d-%d-%d)",s[i].id,s[i].nm,s[i].file.dep,s[i].file.join,s[i].pin,s[i].add,s[i].cont,s[i].file.sal,s[i].da.y,s[i].da.m,s[i].da.d);
	}

}
void sortbybod()
{

}
void sal()
{

}
void sortbydateofjoint()
{

}