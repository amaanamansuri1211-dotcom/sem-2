#include<stdio.h>
#include<conio.h>
struct dob
{
	int y,m,d;
};
struct student
{
	int rno;
	char nm[30];
	int sem;
	char div;
	int sub1,sub2,sub3;
	int total;
	int rank;
	struct dob date;

};
///////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
void getData();
void printData();
void sortbyAge();
void sortbyMarks();
void sortbyRno();
 struct student  s[10];
 struct student temp;
 int n;


///////////////////////////////////////////////////////////////////////
void main()
{

	char c='y';
	int ch;


	clrscr();
	while(c=='y')
	{
	 printf("Welcome to Lj university examination Department");
	 printf("\n 1 input data: \n 2 print Data \n 3 sort Data by Marks \n 4 sort Data by Age \n 5 Sort Data by Roll-No");
	 scanf("%d",&ch);
	 switch(ch)
	 {
	  case 1: getData();break;
	  case 2: printData();break;
	  case 3: sortbyMarks();break;
	  case 4: sortbyAge();break;
	  case 5: sortbyRno();break;
	  default : printf("Wrong choice"); break;


	 }
	 printf("Press 'y' to Continue");flushall();scanf("%c",&c);
	}







	getch();
}
void swap(int i,int j)
{

				temp.rno=s[i].rno;
				s[i].rno=s[j].rno;
				s[j].rno=temp.rno;

				strcpy(temp.nm,s[i].nm);
				strcpy(s[i].nm,s[j].nm);
				strcpy(s[j].nm,temp.nm);


				strcpy(temp.div,s[i].div);
				strcpy(s[i].div,s[j].div);
				strcpy(s[j].div,temp.div);

				strcpy(temp.sem,s[i].sem);
				strcpy(s[i].sem,s[j].sem);
				strcpy(s[j].sem,temp.sem);


				temp.sub1=s[i].sub1;
				s[i].sub1=s[j].sub1;
				s[j].sub1=temp.sub1;

				temp.sub1=s[i].sub2;
				s[i].sub1=s[j].sub2;
				s[j].sub1=temp.sub2;

				temp.sub1=s[i].sub3;
				s[i].sub1=s[j].sub3;
				s[j].sub1=temp.sub3;

				temp.sub1=s[i].total;
				s[i].sub1=s[j].total;
				s[j].sub1=temp.total;

				temp.date.y=s[i].date.y;
				s[i].date.y=s[j].date.y;
				s[j].date.y=temp.date.y;

				temp.date.m=s[i].date.m;
				s[i].date.m=s[j].date.m;
				s[j].date.m=temp.date.m;

				temp.date.d=s[i].date.d;
				s[i].date.d=s[j].date.d;
				s[j].date.d=temp.date.d;



}
void getData()
{
  int i;
  printf("\n Number of student");scanf("%d",&n);

     for(i=0;i<n;i++)
	{
		printf("\nEnter Roll No : "); scanf("%d",&s[i].rno);
		printf("Enter Name : "); scanf("%s",s[i].nm);
		printf("Enter the Semester : "); scanf("%d",s[i].sem);
		printf("Enter the Divison : "); flushall(); scanf("%c",&s[i].div);
		printf("Enter Marks of Adv-c : "); scanf("%d",&s[i].sub1);
		printf("Enter Marks of CS : "); scanf("%d",&s[i].sub2);
		printf("Enter Marks of ES : "); scanf("%d",&s[i].sub3);

		s[i].total = s[i].sub1+s[i].sub2+s[i].sub3;
		printf("\n enter the DOB yyyy/mm/dd:");
		scanf("%d %d %d",&s[i].date.y,&s[i].date.m,&s[i].date.d);
	}

}
void printData()
{
	int i;
	printf("");
	printf("\n %d\t %s\t %d\t %c\t %d\t %d\t %d\t %d\t (%d-%d-%d)",s[i].rno,s[i].nm,s[i].sem,s[i].div,s[i].sub1,s[i].sub2,s[i].sub3,s[i].total,s[i].date.y,s[i].date.m,s[i].date.d);

}
void sortbyAge()
{



}
void sortbyMarks()
{

int i,j;
for(i=0;i<n-1;i++)
{
	for(j=i+1;j<n;j++)
{
 if(s[i].total<s[j].total)
 {
   swap(i,j);
 }//if
}//j
}//i
printData();
}//sortbymark
void sortbyRno()
{
 int i,j;
 for(i=0;i<n-1;i++)
{
	for(j=i+1;j<n;j++)
{
 if(s[i].rno<s[j].rno)
 {
   swap(i,j);
 }//if
}//j
}//i
printData();

}