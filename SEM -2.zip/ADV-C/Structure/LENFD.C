// write a c program to print
#include<stdio.h>
#include<conio.h>
#include<string.h>


void main()
{
	char empid[5];
	int len;
	clrscr();
	printf("\n Enter id Number");scanf("%s",empid);
	len=strlen(empid);
	if(len<3)
	 printf("\n Id is invalid");
	if(len>3)
	printf("Id is invalid");
	if(len==3)
	printf("\n Id is Valid");





	getch();
}