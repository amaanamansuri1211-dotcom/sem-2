#include<stdio.h>
#include<conio.h>
#include<string.h>

struct student
{
	int rno;
	char nm[40];
	char div;
	int sem;
	int sub1,sub2,sub3,total;
};///////////////////////////////////////////////////////////
void main()
{
	struct student s[10];
	struct student temp;
	int i,j;
	clrscr();
	for(i=0;i<3;i++)
	{
	printf("\nEnter Roll no:");scanf("%d",&s[i].rno);
	printf("Enter your Name:");scanf("%s",s[i].nm);
	printf("Enter Division:");flushall();scanf("%c",&s[i].div);
	printf("Enter your Semester:"); scanf("%d",&s[i].sem);
	printf("Enter Adv.C:");scanf("%d",&s[i].sub1);
	printf("Enter CS:");scanf("%d",&s[i].sub2);
	printf("Enter Es:");scanf("%d",&s[i].sub3);
	s[i].total=s[i].sub1+s[i].sub2+s[i].sub3;

	}
	for(i=0;i<2;i++)
	{
		for(j=i+1;j<3;j++)
		{
		 if(s[i].rno>s[j].rno)
		 {
			temp.rno=s[i].rno;
			s[i].rno=s[j].rno;
			s[j].rno=temp.rno;

			strcpy(temp.nm,s[i].nm);
			strcpy(s[i].nm,s[j].nm);
			strcpy(s[j].nm,temp.nm);

			temp.div=s[i].div;
			s[i].div=s[j].div;
			s[j].div=temp.div;

			temp.sem=s[i].sem;
			s[i].sem=s[j].sem;
			s[j].sem=temp.sem;

			temp.sub1=s[i].sub1;
			s[i].sub1=s[j].sub1;
			s[j].sub1=temp.sub1;

			temp.sub2=s[i].sub2;
			s[i].sub2=s[j].sub2;
			s[j].sub2=temp.sub2;

			temp.sub3=s[i].sub3;
			s[i].sub3=s[j].sub3;
			s[j].sub3=temp.sub3;

			temp.total=s[i].total;
			s[i].total=s[j].total;
			s[j].total=temp.total;

		 } //if end

	      } //j  end

	}     //i end
	for(i=0;i<3;i++)
	{
	 printf("\n %d\t %s\t %c\t %d\t %d\t %d\t %d\t %d\t",s[i].rno,s[i].nm,s[i].div,s[i].sem,s[i].sub1,s[i].sub2,s[i].sub3,s[i].total);
	}
 getch();
}