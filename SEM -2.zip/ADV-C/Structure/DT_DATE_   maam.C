#include<stdio.h>
#include<conio.h>
#include<string.h>
struct dob
{
	int y,m,d;
};
struct student
{
	int rno;
	char nm[30];
	int sem;
	char div;
	int sub1,sub2,sub3;
	int total;
	int rank;
	struct dob date;

};
///////////////////function declaration////////////////////////////////
	void swap(int ,int);
///////////////////////global variable///////////////////////////////////
	struct student s[10];
	struct student temp;
		int n;
//////////////////////////////////////////////////////////////////////////
void main()
{
	int i,j;

	clrscr();
	printf("\n Input number of students"); scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nEnter Roll No : "); scanf("%d",&s[i].rno);
		printf("\nEnter Name : "); scanf("%s",s[i].nm);
		printf("\nEnter the Semester : "); scanf("%d",s[i].sem);
		printf("\nEnter the Divison : "); flushall(); scanf("%c",&s[i].div);
		printf("\nEnter Marks of Adv-c : "); scanf("%d",&s[i].sub1);
		printf("\nEnter Marks of CS : "); scanf("%d",&s[i].sub2);
		printf("\nEnter Marks of ES : "); scanf("%d",&s[i].sub3);

		s[i].total = s[i].sub1+s[i].sub2+s[i].sub3;
		printf("\n enter the DOB yyyy/mm/dd:");
		scanf("%d %d %d",&s[i].date.y,&s[i].date.m,&s[i].date.d);
	}
	for(i=0;i<n-1;i++)
	{
	for(j=i+1;j<n;j++)
		{
		if (s[i].date.y>s[j].date.y)
			{swap(i,j);
			}
			else if(s[i].date.y==s[j].date.y)
			{    if (s[i].date.m>s[j].date.m)
				{
				  swap(i,j);
				}//inner
				if(s[i].date.m==s[j].date.m)
				{  	if(s[i].date.d>s[j].date.d)
					{
					swap(i,j);
					}
				}
			  }//else if end
			  else
			  {
			  }
		    }  //for(i)end
	} //for(i)end
	clrscr();
	for(i=0;i<n;i++)
	{
		s[i].rank=i+1;
		printf("\n \t%d \t%s \t%d \t%d \t%d \t%d \t%d\t (%d-%d-%d)",s[i].rno,s[i].nm,s[i].sub1,s[i].sub2,s[i].sub3,s[i].total,s[i].rank,s[i].date.y,s[i].date.m,s[i].date.d);
	}
		getch();
}

  void swap(int i,int j)
  {
				temp.rno=s[i].rno;
				s[i].rno=s[j].rno;
				s[j].rno=temp.rno;

				strcpy(temp.nm,s[i].nm);
				strcpy(s[i].nm,s[j].nm);
				strcpy(s[j].nm,temp.nm);

				temp.sub1=s[i].sub1;
				s[i].sub1=s[j].sub1;
				s[j].sub1=temp.sub1;

				temp.sub1=s[i].sub2;
				s[i].sub1=s[j].sub2;
				s[j].sub1=temp.sub2;

				temp.sub1=s[i].sub3;
				s[i].sub1=s[j].sub3;
				s[j].sub1=temp.sub3;

				temp.sub1=s[i].total;
				s[i].sub1=s[j].total;
				s[j].sub1=temp.total;

				temp.date.y=s[i].date.y;
				s[i].date.y=s[j].date.y;
				s[j].date.y=temp.date.y;

				temp.date.m=s[i].date.m;
				s[i].date.m=s[j].date.m;
				s[j].date.m=temp.date.m;

				temp.date.d=s[i].date.d;
				s[i].date.d=s[j].date.d;
				s[j].date.d=temp.date.d;



  }
