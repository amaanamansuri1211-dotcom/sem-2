// write a c program to print menu with function
#include<stdio.h>
#include<conio.h>