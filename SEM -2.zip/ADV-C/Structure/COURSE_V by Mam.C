#include<stdio.h>
#include<conio.h>
#include<string.h>
////////////////////////////
struct date
{
int d,m,y;
};
////////////////////////////////
struct dept
{
int did;
char nm[50];
char hodnm[50];
} ;
//////////////////////////////////
struct student
{
int sid;
char snm[50];
int year;
int deptid;
struct date dob;
};
/////////////////////////////////////////
struct faculty
{
 int fid;
 char fnm[50];
 int sal;
 int depid;
 };
 /////////////////////////////////
 struct course
 {
 int  id;
 char coursenm[10];
 int credit;
 int deptid;
 };
 //////////////////////////////////
 void getDept();
 void getCourse();

 /////////////////////////////////////////////
 struct dept d[3];
 int k;
struct course c[100];
 /////////////////////////////////////////////
 void main()
 {
 clrscr();
 getDept();
 clrscr();
 getCourse();
 getch();
 }
 //////////////////////////////////////////////////
  void getDept()
  {
	int i;
	for(i=0;i<3;i++)
	{
	printf("enter dept id");scanf("%d",&d[i].did);
	printf("enter dept name");scanf("%s",d[i].nm);
	printf("enter dept hodname ");scanf("%s",d[i].hodnm);
	}


  }
 //////////////////////////////////////////////////////
 void getCourse()
 {
	int i,j;
	int b;
	int flag=0;
	for(i=0;i<3;i++)
	{
	flag=0;

		printf("enter course id:");scanf("%d",&c[i].id);
		printf("enter course coursenm:");scanf("%s",c[i].coursenm);
		printf("enter course credit :");scanf("%d",c[i].credit);
		for(j=0;j<3;j++)
		{
			printf("\n %d\t %s\t",d[j].did,d[j].nm);
		}

		printf("\n select Depart ment id:");
		 scanf("%d",&c[i].deptid);
		for(k=0;k<3;k++)
		{
		if(c[i].deptid==d[k].did)
		{
		flag=1;
		}
		else
		{
		}
		}
		if(flag==1)
		{
		printf("\ncourse created successfully");
		}
			else
		{
		 printf("\n Department id is wrong we can not create course");
		 printf("\n please enter the details agian!");
		 getch();

		 clrscr();
		 getCourse();
		 k++;
		 if(k==3)
		 {
		 printf("\n Sorry ...!");
		}
		}//else



	}


 }
 /////////////////////////////////////////////////////








