#include<stdio.h>
#include<conio.h>
struct student
{
  int rno;
  char nm[100];
  char div;
  int sub1,sub2,sub3,total;
};
void main()
{
	struct student s[10];
	int i,index,max=0;
	clrscr();
	for(i=0;i<3;i++)
	{
	 printf("\n Enter Rollno: ");scanf("%d",&s[i].rno);
	 printf("\n Enter Name: ");scanf("%s",s[i].nm);
	 printf("\n Enter DIivision:");flushall();scanf("%c",&s[i].div);
	 printf("\n Enter ADC.C: ");scanf("%d",&s[i].sub1);
	 printf("\n Enter BM: ");scanf("%d",&s[i].sub2);
	 printf("\n Enter CS: ");scanf("%d",&s[i].sub3);
	 s[i].total=s[i].sub1+s[i].sub2+s[i].sub3;

	 if(s[i].total>max)
	 {
	 max=s[i].total;
	 index=i;
	 }
	 }
	 printf("\n %d\t %s\t %c\t %d\t %d\t %d\t %d\t",s[index].rno,s[index].nm,s[index].div,s[index].sub1,s[index].sub2,s[index].sub3,s[index].total);

       getch();
}