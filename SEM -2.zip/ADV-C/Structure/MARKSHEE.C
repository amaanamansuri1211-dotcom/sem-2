// write a c program to prt
#include<stdio.h>
#include<conio.h>
struct student
{
  int rno;
  char nm;
  char div;
  int sem;
  int sub1,sub2,sub3,total;
  int per;
};
void main()
{
	struct student s[10];
	int i;
	clrscr();
	for(i=0;i<3;i++)
	{
	 printf("\n Enter Rollno: ");scanf("%d",&s[i].rno);
	 printf("\n Enter Name: ");scanf("%s",s[i].nm);
	 printf("\n Enter DIivision:");flushall();scanf("%c",&s[i].div);
	 printf("\n Enter Semester: ");scanf("%d",&s[i].sem);
	 printf("\n Enter ADC.C: ");scanf("%d",&s[i].sub1);
	 printf("\n Enter BM: ");scanf("%d",&s[i].sub2);
	 printf("\n Enter CS: ");scanf("%d",&s[i].sub3);
	 s[i].total=s[i].sub1+s[i].sub2+s[i].sub3;
	}
	clrscr();
	for(i=0;i<3;i++)
	{
	printf("\n");
	printf("...................................................");
	printf("\n");
	printf("\n Rollno\tName\tDIV\tSem\tADV.C\tBM\tCS\tTotal");
	printf("\n");
	printf("\n%d\t%s\t%c\t%d\t%d\t%d\t%d\t%d",s[i].rno,s[i].nm,s[i].div,s[i].sem,s[i].sub1,s[i].sub2,s[i].sub3,s[i].total);
	printf("\n");
	}
	getch();
}