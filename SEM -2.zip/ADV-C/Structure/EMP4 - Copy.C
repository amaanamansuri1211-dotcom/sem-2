#include<stdio.h>
#include<conio.h>
struct date{
int d,y,m;
};
struct profile
{
  int empid;
  char nm[50];
  char phone[10];
  char pincode[8];
  char add[35];
  struct date bod

};
struct corp
{
 int empid;
 int sal;
 char deptnm;
 struct date doj;

};
//////////////////////////////////////////////////////////////////////////
int n;
struct profile p[10];
struct corp c[20];
/////////////////////////////////////////////////////////////////
void getprofile();
void getcrop();
void printprofile();
void printcrop();
///////////////////////////////////////////////////////////////

void main()
{

	clrscr();
	getprofile();
	getcrop();
	printprofile();




	getch();
}
getprofile()
{
 int i;
 printf("\n Enter thr NO. of Employee"); scanf("%d",&n);
 for(i=0;i<n;i++)
 {


	printf("\n Enter Employee id:"); scanf("%d",&p[i].empid);
	printf(" Enter Employee name:"); scanf("%s",p[i].nm);
	printf(" Enter Employee phone:"); scanf("%s",p[i].phone);
	printf(" Enter Employee Pincode:"); scanf("%s",p[i].pincode);
	printf(" Enter Employee Address:"); scanf("%s",p[i].add);
	printf(" Enter Employee YY-MM-DD"); scanf("%d %d %d",&p[i].dob.y,&p[i].dob.m,&p[i].dob.d);




 }
}
void getcrop()
{
	int i;
	 for(i=0;i<n;i++)
 {
	printf("\n Enter Employee id:"); scanf("%d",&p[i].empid);
	c[i].empid=p[i].empid;
	printf(" Enter Employee Department name:"); scanf("%s",c[i].deptnm);
	printf(" Enter Employee Salary:"); scanf("%d",c[i].sal);
	printf(" Enter Employee YY-MM-DD"); scanf("%d %d %d",&c[i].doj.y,&c[i].doj.m,&c[i].doj.d);
	}
}