// write c program
#include<stdio.h>
#include<conio.h>
int lastdg(int num);

void main()
{
///////////////////////////////////////////////////////////////
	int f;
	clrscr();
	printf("");scanf("");
	f=lastdg;

	getch();

}
////////////////////////////////////////////////////////////////
int lastdg(int num)
{
  int ldigit;
  ldigit=num%10;
  return ldigit;


}