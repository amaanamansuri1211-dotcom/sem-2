//write a  c program
#include<stdio.h>
#include<conio.h>
int getid();
int getage();

void main()
{//////////////////////////////////////////////////////////////////////

	clrscr();


	getch();
}//////////////////////////////////////////////////////////////////////
int getid()
{
	int empid;
	printf("\n Enter Employee Id");scanf("%d",&empid);
	return id;

}
int getage()
{
    int age;
    printf("Enter your Age");scanf("%d",&age);
    return age;
}