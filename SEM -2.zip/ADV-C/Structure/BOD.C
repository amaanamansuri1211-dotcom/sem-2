
#include<stdio.h>
#include<conio.h>
struct dob
{
  int y,m,d;
};
struct student
{
	int rno;
	char nm[40];
	char div;
	int sub1,sub2,sub3,total,rank;
	struct dob date;
};


void main()
{
	struct student s[10];
	struct student temp;
	int i,j;
	clrscr();
	for(i=0;i<3;i++)
	{
	printf("\nEnter Roll no:");scanf("%d",&s[i].rno);
	printf("Enter your Name:");scanf("%s",s[i].nm);
	printf("Enter Division:");flushall();scanf("%c",&s[i].div);
	printf("Enter Adv.C:");scanf("%d",&s[i].sub1);
	printf("Enter CS:");scanf("%d",&s[i].sub2);
	printf("Enter Es:");scanf("%d",&s[i].sub3);
	s[i].total=s[i].sub1+s[i].sub2+s[i].sub3;

	printf("Enter ypur birth In YY-MM-DD ");scanf("%d %d %d",&s[i].date.y,&s[i].date.m,&s[i].date.d);

	}
	for(i=0;i<2;i++)
	{
		for(j=i+1;j<3;j++)
		{
		 if(s[i].total<s[j].total)
		 {
			temp.rno=s[i].rno;
			s[i].rno=s[j].rno;
			s[j].rno=temp.rno;

			strcpy(temp.nm,s[i].nm);
			strcpy(s[i].nm,s[j].nm);
			strcpy(s[j].nm,temp.nm);

			strcpy(temp.div,s[i].div);
			strcpy(s[i].div,s[j].div);
			strcpy(s[j].div,temp.div);

			temp.sub1=s[i].sub1;
			s[i].sub1=s[j].sub1;
			s[j].sub1=temp.sub1;

			temp.sub2=s[i].sub2;
			s[i].sub2=s[j].sub2;
			s[j].sub2=temp.sub2;

			temp.sub3=s[i].sub3;
			s[i].sub3=s[j].sub3;
			s[j].sub3=temp.sub3;

			temp.total=s[i].total;
			s[i].total=s[j].total;
			s[j].total=temp.total;

			temp.date.y=s[i].date.y;
			s[i].date.y=s[j].date.y;
			s[j].date.y=temp.date.y;

			temp.date.m=s[i].date.m;
			s[i].date.m=s[j].date.m;
			s[j].date.m=temp.date.m;

			temp.date.d=s[i].date.d;
			s[i].date.d=s[j].date.d;
			s[j].date.d=temp.date.d;


		 } //if end

	      } //j  end

	}     //i end
	for(i=0;i<3;i++)
	{
	 s[i].rank=i+1;
	 printf("\n Rollno\t Name\t div\t sem\t Adv.c\t ca\t Es\t Total\t Rank\t YY-MM-DD");
	 printf("\n %d\t %s\t %c\t %d-%d-%d\t %d\t %d\t %d-%d-%d",s[i].rno,s[i].nm,s[i].div,s[i].sub1,s[i].sub2,s[i].sub3,s[i].total,s[i].rank,s[i].date.y,s[i].date.m,s[i].date.d);


	}
 getch();
}