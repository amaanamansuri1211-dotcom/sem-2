#include<stdio.h>
#include<conio.h>
union st{

 int rno;
 char nm[45];
 int age;

};
void main()
{
       union st s1;
	clrscr();
	printf("\n Enter the Roll no"); scanf("%d",&s1.rno);
	printf("\n Enter the Name"); scanf("%s",s1.nm);
	printf("\n Enter the Age"); scanf("%d",&s1.age);
	printf("\n %d\t %s\t %d",s1.rno,s1.nm,s1.age);
	getch();
}