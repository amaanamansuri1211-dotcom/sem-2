#include<stdio.h>
#include<conio.h>
void add();
void sub();
void multi();
void div();
void main()
{       int ch;
	char c='y';

	clrscr();
	while(c=='y')
	{
	printf("\n 1 for Addition \n 2 for substraction \n 3 for multiplication \n 4 for divition");
	scanf("%d", &ch);
	switch(ch)
	{
      case 1: add();  break;
      case 2: sub();  break;
      case 3: multi(); break;
      case 4: div();   break;
      default : printf("\n wrong choice");
	}// end of the switch case
	printf("\n press y For Continue");flushall(); scanf("%c",&c);
	}// end of the while loop
	getch();


}
void add()
{
    int a,b,c;
    printf("\n Enter two Number");scanf("%d %d",&a,&b);
    c=a+b;
    printf("\n the Answeris %d",c);
}
void sub()
{
	int a,b,c;
	printf("\n Enter the two number");scanf("%d %d",&a,&b);
	c=a-b;
	printf("\n the Answer is %d",c);

}
void multi()
{
	int a,b,c;
    printf("\n Enter two Number");scanf("%d %d",&a,&b);
    c=a*b;
    printf("\n the Answeris %d",c);
}
void div()
{
	 int a,b,c;
    printf("\n Enter two Number");scanf("%d %d",&a,&b);
    c=a/b;
    printf("\n the Answeris %d",c);
}