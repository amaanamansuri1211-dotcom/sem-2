#include<stdio.h>
#include<conio.h>
struct List
{
	int rno;
	struct List *next;

};
/////////////////////////////////////////////////////////////////////////////
void create();
void display();
//////////////////////////////////////////////////////////////////////////
struct List *first,*node;
int n;
/////////////////////////////////////////////////////////////////////////////
void main()
{
clrscr();

create();
display();

getch();


}
void create()
{
  int i;
  printf("\nEnter number of student:");scanf("%d",&n);
  node=(struct List *)malloc(sizeof(struct List));
  first=node;
  for(i=1;i<=n;i++)
  {
  printf("\nEnter Roll no. ");scanf("%d",&node->rno);
  if(i==n)
  {
   node->next=NULL;
  }
  else
  {
  node->next=(struct List *)malloc(sizeof(struct List));
  node=node->next; //jump to the next block
  }
 }
}
void display()
{
 int i;
 node=first;
 for(i=1;i<=n;i++)
 {
  printf("\n %d||%p||%p",node->rno,node,node->next);
  node=node->next;//jump to next block
 }
}