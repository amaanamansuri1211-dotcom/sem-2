#include<stdio.h>
#include<conio.h>
#include<malloc.h>
/////////////////////////////////struct declare/////////////////////////////////
struct Sll
{
	int rno;
	char nm[30];
	struct  Sll *next;

};
////////////////////////////// globle value /////////////////////////////////////
int n;
struct Sll *first,*node;
void display();
void create();
void insert();
void search();
void delete1();


//////////////////////////////// main //////////////////////////////////////
void main()

{

   int ch;
	   char c='y';
	   clrscr();
	   while(c=='y')
	   {
	     printf("\npress 1 to create:");
	     printf("\n press 2 to display:");
	     printf("\n press 3 to insert:");
	     printf("\n press 4 to search:");
	     printf("\n press 5 to delete:");

	     scanf("%d",&ch);
	     switch(ch)
	     {

	      case 1:create();break;
	      case 2:display();break;
	      case 3:insert(); break;
	      case 4:search(); break;
	      case 5: delete1(); break;

	      default:printf("\n wrong choise"); break;
	      }
	      printf("\press y to continue:");flushall(); scanf("%c",&c);
	      }
	create();
	display();
	insert();
	search();
	delete1();
	getch();
}
/////////////////////////// function /////////////////////////////////////
void display()
{
	int i;
	node=first;
	for(i=1;i<=n;i++)
	{
	printf("\n%d ||%s ||%p ",node->rno,node->nm,node->next);
	node=node->next;
	}

}        //////////////////////////////////////////
void create()
{
	int i;
	  printf("\n Enter no. node");scanf("%d",&n);
	  node=(struct Sll *)malloc(sizeof(struct Sll));
	  first=node;
	  for(i=1;i<=n;i++)
	  {
	   printf("\n Enter the Roll no:");  scanf("%d",&node->rno);
	   printf("Enter the  Name :");  scanf("%s",node->nm);
	   if(i==n)
	   {
	   node->next=NULL;
	   }
	   else
	   {
	   node->next=(struct Sll *)malloc(sizeof(struct Sll));
	   node=node->next;
	   }
	   }
}
void insert()
{
  int i;
  int pos;
   struct Sll *newnode;
   node=first;
   newnode=(struct Sll *)malloc(sizeof (struct Sll));
   newnode->next=NULL;
   printf("\n enter rollno"); scanf("%d",&newnode->rno);
   printf("\n input position"); scanf("%d",&pos);
   if(pos==1)
   {
    newnode->next=first;
    first=newnode;
    n++;
   }
   else
   {
     for(i=1;i<=pos-2;i++)
     {
     node=node->next;
   }
    newnode->next=node->next;
    node->next=newnode;
    n++;
   }
}
void search()
{
 int i;
 int info,flag=0;
 printf("enter roll no to search");
 scanf("%d",&info);
 node=first;
 for(i=1;i<=n;i++)
 {
   if(node->rno==info)
   {
     printf("\n data found at position %d",i);
     flag=1;
     break;
   }
}
 if(flag==0)
 {
  printf("\n data not found");
 }
}
/////////////////////delete///////////////////////////////
void delete1()
{
  int i,data;
  node=first;

   printf("\n enter the delete data:"); scanf("%d",&data);
   if(first->rno==data)
   {
      first=first->next;
      n--;
  }
  else
  {
     for(i=2;i<=n;i++)
     {
       if(data==node->next->rno)
       {
	    node->next=node->next->next;
	    n--;
	}
       node=node->next;

     }
}
}