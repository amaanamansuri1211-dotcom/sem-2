#include<stdio.h>
#include<conio.h>
#include<malloc.h>
/////////////////////////////////struct declare/////////////////////////////////
struct Sll
{
	int rno;
	char nm[30];
	struct  Sll *next;

};
////////////////////////////// globle value /////////////////////////////////////
int n;
struct Sll *first,*node;
void display();
void create();

//////////////////////////////// main //////////////////////////////////////
void main()

{

clrscr();
	create();
	display();
getch();
}
/////////////////////////// function /////////////////////////////////////
void display()
{
	int i;
	node=first;
	for(i=1;i<=n;i++)
	{
	printf("\n%d ||%s ||%p ",node->rno,node->nm,node->next);
	node=node->next;
	}

}        //////////////////////////////////////////
void create()
{
	int i;
	  printf("\n Enter no. node");scanf("%d",&n);
	  node=(struct Sll *)malloc(sizeof(struct Sll));
	  first=node;
	  for(i=1;i<=n;i++)
	  {
	   printf("\n Enter the Roll no:");  scanf("%d",&node->rno);
	   printf("Enter the  Name :");  scanf("%s",node->nm);
	   if(i==n)
	   {
	   node->next=NULL;
	   }
	   else
	   {
	   node->next=(struct Sll *)malloc(sizeof(struct Sll));
	   node=node->next;
	   }
	   }
}