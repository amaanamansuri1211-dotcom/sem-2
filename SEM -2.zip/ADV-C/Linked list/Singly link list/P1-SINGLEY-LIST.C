#include<stdio.h>
#include<conio.h>
#include<malloc.h>


	struct List
	{
	int rno;
	struct List *next;
	};
	////////////////// function Declaraction ///////////////////
	void create();
	void display();
	void insert();
	void delet();
	void updata();
	void search();
	///////////////////// Global Value //////////////////////
	struct List *first,*node;
	int n;
	//////////////////////////////////////////////////
	void main()
	{
	int ch;
	char c='y';
	clrscr();
	while(c=='y')
	{
		printf("\n Press 1 to create:");
		printf("\n Press 2 to Display:");
		printf("\n Press 3 to Insert:");
		printf("\n Press 4 to Delete:");
		printf("\n Press 5 to Update:");
		printf("\n Press 6 to Search:");
		scanf("%d",&ch);
		switch(ch)
		{
		 case 1: create(); break;
		 case 2: display(); break;
		 case 3: insert(); break;
		 case 4: delet(); break;
		 case 5: updata(); break;
		 case 6:search(); break;
		 default: printf("\n Wrong choice");  break;
		}
		printf("\n Press y to continue:"); flushall(); scanf("%c",&c);

	}
		getch();
	}
	/////////////// function //////////////////////////////////

	////////////////// Create ///////////////////////////////
	void create()
	{
	int i;
	printf("Enter the No.of student"); scanf("%d",&n);
	// create First node
	node=(struct List *)malloc(sizeof(struct List));
	//take the backup
	first=node;
	for(i=1;i<=n;i++)
	{
	 printf(" Enter the R-no.");  scanf("%d",&node->rno);
	 if(i==n)
		node->next=NULL;
	 else
	 {
	 // create a memmery
	 node->next=(struct List *)malloc(sizeof(struct List));
	 // second memmery
	 node=node->next;  // jump to next black
	  }//else

	}// for

	}// create
	///////////////// Display //////////////////////////////
	void display()
	{
	int i;
	node=first;
	for(i=1;i<=n;i++)
	{
	printf("\n%d ||%p ||%p",node->rno,node,node->next);
	node=node->next; //jump to the next node


	}//for
	}/// display
	/////////////////// Insert ///////////////////////////////////////////
	void insert()
	{
	int i,pos;
	struct List *newnode;
	node=first;
	newnode=(struct List *)malloc(sizeof(struct List));
	newnode->next=NULL;
	printf("\n Enter the Roll-no:"); scanf("%d",&newnode->rno);
	printf("\n Enter the Position:"); scanf("%d",&pos);

	if(pos==1)
	{

	newnode->next=first;
	first=newnode;
	n++;  // increase count

	}//if
	else
	{
	 //
	 for(i=1;i<=pos-2;i++)
	 {
	 node=node->next;
	 }  //for

	  newnode->next=node->next;
	  node->next=newnode;
	  n++;
	}   // else

	}/// Insert
	//////////////////// Delete ///////////////////////////////////////
	void delet()
	{
	int i,data;
	node=first;
	printf("\n Enter the Delete Data:"); scanf("%d",&data);

	if(first->rno==data)
	  {
	  first=first->next;
	  n--;
	  }
	else
	{

      for(i=2;i<=n;i++)
	{
	if(data==node->next->rno)
	{
		node->next=node->next->next;
		n--;
	}//if
	     node=node->next;
       }//for
	   }//delete
	}
	//////////////////// Updata //////////////////////////////////////
	void updata()
	{

	}//// updata
	//////////////////// Search //////////////////////////////////////
	void search()
	{
	int i;
	int info;
	int flag=0;

	printf("\n Entere the Roll_no To Serach"); scanf("%d",&info);
	node=first;  // Reset

	for(i=1;i<=n;i++)
	{
	if(node->rno==info)
	{
	printf("\n Data Found at Position %d",i);
	flag=1;
	break;
	}//if
	}//for
	     if(flag=0)
		       printf("\n Data Not Found");


	}// Search





