#include<stdio.h>
#include<conio.h>
#include<malloc.h>
/////////////////////////////////struct declare/////////////////////////////////
struct Sll
{
	int rno;
	char nm[30];
	struct  Sll *next;

};
////////////////////////////// globle value /////////////////////////////////////
int n;
struct Sll *first,*node;
void display();
void create();
void insert();
void search();

//////////////////////////////// main //////////////////////////////////////
void main()

{
	int ch;
	char c='y';
	clrscr();
	while(c=='y')
	{
		printf("\n Press 1 to create:");
		printf("\n Press 2 to Display:");
		printf("\n Press 3 to Insert:");
		printf("\n Press 4 to Search:");
	      //	printf("\n Press 5 to Update:");
		scanf("%d",&ch);
		switch(ch)
		{
		 case 1: create(); break;
		 case 2: display(); break;
		 case 3: insert(); break;
		 case 4: search(); break;
		// case 5: updata(); break;
		 default: printf("\n Wrong choice");  break;
		}
		printf("\n Press y to continue:"); flushall(); scanf("%c",&c);
		}

	search();
	create();
	display();
	insert();
	getch();
}
/////////////////////////// function /////////////////////////////////////
void display()
{
	int i;
	node=first;
	for(i=1;i<=n;i++)
	{
	printf("\n%d ||%s ||%p ",node->rno,node->nm,node->next);
	node=node->next;
	}

}        //////////////////////////////////////////
void create()
{
	int i;
	  printf("\n Enter no. node");scanf("%d",&n);
	  node=(struct Sll *)malloc(sizeof(struct Sll));
	  first=node;
	  for(i=1;i<=n;i++)
	  {
	   printf("\n Enter the Roll no:");  scanf("%d",&node->rno);
	   printf("Enter the  Name :");  scanf("%s",node->nm);
	   if(i==n)
	   {
	   node->next=NULL;
	   }
	   else
	   {
	   node->next=(struct Sll *)malloc(sizeof(struct Sll));
	   node=node->next;
	   }
	   }
}
void insert()
{
	int i,pos;
	struct Sll *newnode;
	node=first;
	newnode=(struct Sll *)malloc(sizeof(struct Sll));
	newnode->next=NULL;
	printf("\n Enter Roll-no.");scanf("%d",&newnode->rno);
	printf("\n Enter Name.");scanf("%s",newnode->nm);

	printf("\n input position");scanf("%d",&pos);
	if(pos==1)
	{
	 newnode->next=first;
	 first=newnode;
	 n++;
	}
	else
	{
	 for(i=1;i<=pos-2;i++)
	 {
	  node=node->next;
	 }
	 newnode->next=node->next;
	 node->next=newnode;
	 n++;
	}

}
void search()
{
	int i,info,flag=0;
	printf("Enter roll-no of search");scanf("%d",&info);
	node=first;
	for(i=1;i<=n;i++)
	{
	if(node->rno==info)
	{
	printf("\n data found at position %d",i);
	flag=1;
	break;
	}
	}
	if(flag==0)
	{
	 printf("\n data not found");
	}
}


