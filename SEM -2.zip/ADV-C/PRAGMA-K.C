#include<stdio.h>
#include<conio.h>
void fun1();
void fun2();
#pragma start fun1
#pragma exit fun2
void fun1 (){printf("\n Inside func1()\n");}
void fun2 (){ printf("\n outside fun2()\n");}
void main()
{
printf("\n inside mian()\n");
getch();
}