// write a c program to print
#include<stdio.h>
#include<conio.h>
void  add(int,int);
void  sub(int ,int);
int  multi(int,int);
int divi(int,int);
void main()
{
	int a,b,f,g;
	char ch;
	char w='y';
	clrscr();
	printf("\n Enter the value of a and b"); scanf("%d %d",&a,&b);
	while(w=='y')
	{
	printf("\n + for Add,\n - for sub,\n * for multi, \n / for divi ");
	flushall(); scanf("%c",&ch);
       switch(ch)
       {
     case '+':add(a,b);  break;
     case '-':sub(a,b); break;
     case '*':f=multi(a,b);
		printf("\n multiplay of two number %d",f);      break;
     case '/':	g=divi(a,b);
		printf("\n divition of two number %d",g);        break;
	default : printf("\n wrong choice"); break;

       }  // switch
       printf("\n press y to continue");flushall(); scanf("%c",&w);

       }// while



	getch();
}
void  add(int a,int b)
{
	int c;
	c=a+b;
	printf("\n the Answer of Addition %d",c);


}
void sub(int a,int b)
{
    int z;
    z=a-b;
    printf("\n The Answer of Substraction %d",z);
}
int multi(int a,int b)
{
   int f;
   f=a*b;
   return f;

}
int divi(int a,int b)
{
	int g;
	g=a/b;
	return g;

}