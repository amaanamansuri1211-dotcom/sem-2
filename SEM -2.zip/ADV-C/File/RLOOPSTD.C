#include<stdio.h>
#include<conio.h>
#include<string.h>
struct student
{
char id[3];
char nm[8];
char add[10];
char phno[10];
char age[3];
};
void main()
{
struct student s;
	FILE *fp;
	int i,n,flag=0;
	char temp[5];
	clrscr();

       fp=fopen("student1.txt","r");
	if(fp)
	{
	printf("\n input roll no to search");
	scanf("%s",temp);
	for(i=1;i<=3;i++)
	{
	  fscanf(fp,"%s %s",s.id,s.nm);
	  n=strcmp(temp,s.id);
	  if(n==0)
	  {
	  flag=1;
	  printf("\n %s %s",s.id,s.nm);
	  }
	  }
	  if(flag==0)
	  {
	   printf("\n data not found");
	  }
	 }
	  fclose(fp);
	  getch();
}