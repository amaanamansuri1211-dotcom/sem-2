#include<stdio.h>
#include<conio.h>



void main()
{
	FILE *f1;
	char p[30];
	clrscr();
	f1=fopen("data2.txt","r");
	if(f1)
	{
	 fscanf(f1,"%s",p);

	 printf("\n %s\t",p);


	}
	else
	{
	 printf(" \n Error !!! file no open");

	}
	fclose(f1);

	getch();

}