#include<stdio.h>
#include<conio.h>
struct course
{
char cor_id[3];
char cor_nm[30];
};
void main()
{
struct course c;
FILE *fp;

clrscr();
       fp=fopen("course.txt","r");
	if(fp)


	{
	fscanf(fp,"%s%s",c.cor_id,c.cor_nm);
	printf("\n %s",c.cor_id);
	printf("\n %s",c.cor_nm);

	}

 fclose(fp);
 getch();
}