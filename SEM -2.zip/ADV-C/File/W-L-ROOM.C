#include<stdio.h>
#include<conio.h>
struct house
{
	int id;
	int rms;
	int area;
	char loc[50];
	int pri;
};
struct house h;
void save();
void list();
void search();
void main()
{

	int ch;
	char c='y';
	clrscr();
	while(c=='y')
	{
		printf("\n Press 1 to insert data:");
		printf("\n Press 2 to list all employee:");
		printf("\n Press 3 to search :");
		scanf("%d",&ch);
		switch(ch)
		{
		 case 1: savedata(); break;
		 case 2: printdata(); break;
		 case 3: searchdata(); break;
		 default: printf("\n Wrong choice");  break;
		}
		printf("\n Press y to continue:"); flushall(); scanf("%c",&c);

	}
	save();
	list();

	getch();
}
void save()
{

	FILE *fp;
	int n,i;
	clrscr();
	fopen("house.txt","w");
	 if(fp)
	 {
	 printf("\n Enter the No.of Appartment You want to sell out");
	 scanf("%d",&n);
	 for(i=1;i<=n;i++)
	 {
		printf("\n Enter Room id:\t");scanf("%d",&h.id);
		printf("Enter Room: \t");scanf("%d",&h.rms);
		printf("Enter Room area in (sqft) :\t");scanf("%d",&h.area);
		printf("Enter Address :\t");scanf("%s",h.loc);
		printf("Enter price :\t");scanf("%d",&h.pri);
	 }
	 }
	 else
	 {
	  printf("\n error in file open");
	 }
	 fclose(fp);
}
void list()
{
	FILE *fp;
	int n;
	clrscr();
	fopen("house.txt","r");
	 if(fp)
	 {
	 while(fscanf(fp,"%d %d %d %s %d",&h.id,&h.rms,&h.area,h.loc,&h.pri)==5)
	 {
		printf("%d",h.id);
		printf("%d",h.rms);
		printf("%d",h.area);
		printf("%s",h.loc);
		printf("%d",h.pri);
	 }
	 }
	 else
	 {
	  printf("\n error in file open");
	 }
	 fclose(fp);
}

void search()
{

	FILE *fp;
	int i,n,flag=0;
	char temp[3];
	struct house h;
	clrscr();
	fp=fopen("house.txt","r");
	if(fp)
	{
		printf("\n Enter Room id:");
	       scanf("%s",temp);
	       for(i=1;i<=3;i++)
	       {
			fscanf(fp,"%d %d %d %s %d",h.id,h.rms,h.area,h.loc,h.pri)
			n=strcmp(temp,h.id);
			if(n==0)
			{
			flag=1;
			printf("\n Record found");
			printf("\n %d %d %d %s %d",h.id,h.rms,h.area,h.loc,h.pri);
			 }
		 } //for
			if(flag==0)
			{
			 printf("\n Record not found");
			 }

	}
	fclose(fp);
}