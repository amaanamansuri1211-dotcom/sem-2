#include<stdio.h>
#include<conio.h>
struct student
{
char id[3];
char nm[30];
char add[30];
char phno[10];
char age[100];
};
void main()
{
struct student s;
FILE *fp;

clrscr();
       fp=fopen("student.txt","w");
	if(fp)
	{
	 printf("\n Enter Student id Max 999:");scanf("%s",s.id);
	 printf("\n Enter Student Name:");scanf("%s",s.nm);
	  printf("\n Enter Studrnt Address:");scanf("%s",s.add);
	  printf("\n Enter Student PH:Number:");scanf("%s",s.phno);
	  printf("\n Enter Student Age:");scanf("%s",s.age);

	 fprintf(fp,"%s%s%s%s%s",s.id,s.nm,s.add,s.phno,s.age);

	}
	else
	{
	 printf("\n sorry!! file open error");
	}
	fclose(fp);
	getch();

}