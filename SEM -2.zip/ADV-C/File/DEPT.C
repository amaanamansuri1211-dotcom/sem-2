#include<stdio.h>
#include<conio.h>
struct department{
	char id[3];
	char nm[8];
	char dept[4];
};
int n=6;
void saveData();
void printData();
void searchData();
struct department e;
void main()
{
	int ch;
	char c='y';
	clrscr();
	while(c=='y')
	{
	printf("\n press 1 to insert Data");
	printf("\n press 2 to List all the Employee");
	printf("\n press 3 to Search Data");
	scanf("%d",&ch);
	switch(ch)
	{
	 case 1:saveData(); break;
	 case 2:printData();  break;
	 case 3:searchData();  break;
	 default :printf("error Wrong choice"); break;
	 }
	 printf("\n Press y to continue");flushall();scanf("%c",&c);
	 }
	getch();
}
void saveData()
{
	FILE *fp;
	int i;
	fp=fopen("dept1.txt","w");
	if(fp)
	{
		printf("\n Enter number of Employee");scanf("%d",&n);
	for(i=1;i<=n;i++)
      {


	printf("\n Enter dept id:");scanf("%s",e.id);
	printf("\n Enter Name:");scanf("%s",e.nm);
	printf("\n Enter dept:");scanf("%s",e.dept);
	fprintf(fp,"%s %s %s\n",e.id,e.nm,e.dept);
	}

	}
	else
	{
	printf("\n sorry file not open");
	}
	fclose(fp);
}
void printData()
{
	FILE *fp;
	int i;
	int n=6;
	fp=fopen("dept1.txt","r");
	if(fp)
	{
	for(i=1;i<=n;i++)
	printf("\n Enter number of Employee");scanf("%d",&n);
	{
	fscanf(fp,"%s %s %s",e.id,e.nm,e.dept);
	printf("%s %s %s",e.id,e.nm,e.dept);
	}

	}
	else
	{
	printf("\n sorry file not open");
	}
	fclose(fp);


}
void searchData()
{

}