#include<stdio.h>
#include<conio.h>
struct student
{
char id[3];
char nm[30];
char add[30];
char phno[10];
char age[100];
};
void main()
{
struct student s;
FILE *fp;

clrscr();
       fp=fopen("student.txt","r");
	if(fp)
	{
	fscanf(fp,"%s %s %s %s %s",s.id,s.nm,s.add,s.phno,s.age);
	printf("\n %s",s.id);
	printf("\n %s",s.nm);
	printf("\n %s",s.add);
	printf("\n %s",s.phno);
	printf("\n %s",s.age);
    }
		else
	{
	 printf("\n sorry!! file open error");
	}
	fclose(fp);
	getch();

}