#include<stdio.h>
#include<conio.h>
struct student
{
char id[3];
char nm[8];
char add[10];
char phno[10];
char age[3];
};
void main()
{
struct student s;
	FILE *fp;
	int i;
	clrscr();

       fp=fopen("student1.txt","w");
	if(fp)
	{
	for(i=1;i<=3;i++)
	{

	 printf("\n Enter Student id Max 999:");scanf("%s",s.id);
	 printf("Enter Student Name:");scanf("%s",s.nm);
	 // printf("Enter Studrnt Address:");scanf("%s",s.add);
	//  printf("Enter Student PH:Number:");scanf("%s",s.phno);
	//  printf("Enter Student Age:");scanf("%s",s.age);

	 fprintf(fp,"%s%s",s.id,s.nm);//s.add,s.phno,s.age);
	}
	}
	else
	{
	 printf("\n sorry!! file open error");
	}
	fclose(fp);
	getch();

}