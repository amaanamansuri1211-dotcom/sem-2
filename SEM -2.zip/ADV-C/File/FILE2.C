#include<stdio.h>
#include<conio.h>



void main()
{
	FILE *f1;
	char p[30];
	clrscr();
	f1=fopen("data2.txt","w");
	if(f1)
	{
	 printf("\nEnter your Name");flushall();scanf("%s",p);
	 fprintf(f1,"%s",p)
	 putc(p,f1);
	}
	else
	{
	 printf(" \n Error !!! file no open");

	}
	fclose(f1);

	getch();

}