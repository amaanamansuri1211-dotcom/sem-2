#include<stdio.h>
#include<conio.h>
struct course
{
char cor_id[3];
char cor_nm[30];
};
void main()
{
struct course c;
FILE *fp;

clrscr();
       fp=fopen("course.txt","w");
	if(fp)
	{
	 printf("\n Enter Your Course_id Max 999:");scanf("%s",c.cor_id);
	 printf("\n Enter Your Course_Nam:");scanf("%s",c.cor_nm);
	 fprintf(fp,"%s %s",c.cor_id,c.cor_nm);

	}
	else
	{
	 printf("\n sorry!! file open error");
	}
	fclose(fp);
	getch();

}