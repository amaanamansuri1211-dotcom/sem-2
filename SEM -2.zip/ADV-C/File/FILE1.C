#include<stdio.h>
#include<conio.h>



void main()
{
	FILE *f1;
	char p;
	clrscr();
	f1=fopen("data1.txt","w");
	if(f1)
	{
	 printf("\nEnter char");flushall();scanf("%c",&p);

	 putc(p,f1);
	}
	else
	{
	 printf(" \n Error !!! file no open");

	}
	fclose(f1);

	getch();

}