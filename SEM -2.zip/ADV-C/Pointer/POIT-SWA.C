#include<stdio.h>
#include<conio.h>
void swap(int *,int *);
void main()
{
	int a,b;
	clrscr();
	printf("\n Input A and b "); scanf("%d %d",&a,&b);
	printf("\n The value Before swaping id A=%d ,B=%d",a,b);
	swap(&a,&b);
	printf("\n The value after swaping id A=%d,b=%d",a,b);
	getch();



}
void swap(int *a,int* b)
{
	int temp;
	temp=*a;
	*a=*b;
	*b=temp;

}