#include<stdio.h>
#include<conio.h>


void main()
{
	int **p;
	int *q;
	int r=7;
	clrscr();
	q=&r;
	p=&q;
	printf("\n The Value of r Using of q %d",*q);
	printf("\n The Address of r %p ",q);
	printf("\n The Address of p %p",p);
	printf("\n The Address of q %p",&p);
	printf("\n The Value of r Using of q is %d",**p);

	getch();
}