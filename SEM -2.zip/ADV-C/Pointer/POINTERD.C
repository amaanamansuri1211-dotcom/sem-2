// write a c prohram to print pointrt
#include<stdio.h>
#include<conio.h>

void main()
{
       int a;
       int *ptr;
       clrscr();
       a=5;
       ptr=&a;
       printf("\n the value ofa is %d",a);
       printf("\n The Value of a is %d",*ptr);


	getch();
}