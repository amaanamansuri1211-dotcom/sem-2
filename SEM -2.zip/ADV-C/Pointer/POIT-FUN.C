#include<stdio.h>
#include<conio.h>
void diff(int,int,int *,int *,int *,int *);
void main()
{

	int a,b;
	int add,sub,multi,div;
	clrscr();
	printf("\n Enter Two Digit"); scanf("%d %d",&a,&b);
	diff(a,b,&add,&sub,&multi,&div);
	printf("\n add\t sub\t Multi\t Div\t");
	printf("\n %d\t %d\t %d\t %d\t",add,sub,multi,div);
	getch();


}
void diff(int a,int b,int *add,int *sub,int *multi,int *div)
{
 *add=a+b;
 *sub=a-b;
 *multi=a*b;
 *div=a/b;

}