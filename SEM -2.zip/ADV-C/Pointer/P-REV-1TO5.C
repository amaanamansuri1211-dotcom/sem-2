#include<stdio.h>
#include<conio.h>

void main()
{
	int a[10];
	int *p;
	int i;
	clrscr();
	p=&a[0];
	for(i=0;i<10;i++)
	{
	printf("\n Next");
	scanf("%d",p);
	p++;
	}
	p=&a[4];
	for(i=0;i<5;i++)
	{
	printf("\n \t%d",*p);
	p--;
	}


	getch();
}
