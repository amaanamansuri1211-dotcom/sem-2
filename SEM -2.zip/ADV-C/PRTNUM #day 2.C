
#include<stdio.h>
#include<conio.h>
void printnum();
void main()
{
	clrscr();
	printnum();



	getch();
}
void printnum()
{
	int i;
	for (i=1;i<=10;i++)
	{
	 printf("\n %d",i);
	}


}